import App from './App.js'

let app = new App();
app.render('#app')