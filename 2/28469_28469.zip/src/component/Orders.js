class Orders {

}

export default Orders;