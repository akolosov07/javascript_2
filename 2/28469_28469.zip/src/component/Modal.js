class Modal {
   
}

export default Modal;