class Customer {

}

export default Customer;