class Reports {
    
	
}
export default Reports;