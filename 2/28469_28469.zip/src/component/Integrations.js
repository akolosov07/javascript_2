class Integrations {
    
}

export default Integrations;