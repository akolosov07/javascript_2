class Goods {
  
}

export default Goods;