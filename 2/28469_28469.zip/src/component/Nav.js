class Nav {
    
}

export default Nav;