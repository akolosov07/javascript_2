class Dashboard {
    
}

export default Dashboard;